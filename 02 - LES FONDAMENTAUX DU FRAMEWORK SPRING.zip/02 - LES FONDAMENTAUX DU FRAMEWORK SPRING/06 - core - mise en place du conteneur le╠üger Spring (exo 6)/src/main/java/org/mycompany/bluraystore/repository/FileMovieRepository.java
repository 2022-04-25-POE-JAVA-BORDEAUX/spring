package org.mycompany.bluraystore.repository;

import org.mycompany.bluraystore.entity.Movie;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

// changement opéré
public class FileMovieRepository implements MovieRepositoryInterface {

    // maintenant le nom du fichier et le type du fichier à générer est paramètrable dans applicationContext.xml
    private File file;

    public void add(Movie movie) {

        try {
            FileWriter writer = new FileWriter(file, true);
            writer.write(movie.getTitle() + ";" + movie.getGenre() + "\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }
}
