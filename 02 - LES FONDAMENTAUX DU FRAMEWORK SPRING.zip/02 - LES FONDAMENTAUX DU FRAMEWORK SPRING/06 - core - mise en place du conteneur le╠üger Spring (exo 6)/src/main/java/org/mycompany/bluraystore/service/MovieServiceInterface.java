package org.mycompany.bluraystore.service;

import org.mycompany.bluraystore.entity.Movie;
import org.mycompany.bluraystore.repository.MovieRepositoryInterface;

public interface MovieServiceInterface {

    public void registerMovie(Movie movie);
    public void setRepository(MovieRepositoryInterface repository);
}
