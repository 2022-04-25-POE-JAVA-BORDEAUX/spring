package org.mycompany.bluraystore.controller;

import org.mycompany.bluraystore.entity.Movie;
import org.mycompany.bluraystore.service.MovieServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Scanner;

public class MovieController {

    @Autowired
    private MovieServiceInterface service;

    public void addUsingConsole() {
        String title, genre;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a title :");
        title = scanner.nextLine();

        System.out.println("Enter a genre :");
        genre = scanner.nextLine();

        Movie movie = new Movie();
        movie.setGenre(genre);
        movie.setTitle(title);

        service.registerMovie(movie);
    }

    public MovieServiceInterface getService() {
        return service;
    }

    public void setService(MovieServiceInterface service) {
        this.service = service;
    }
}
