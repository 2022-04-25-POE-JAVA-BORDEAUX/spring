package org.mycompany.bluraystore;

import org.mycompany.bluraystore.controller.MovieController;
import org.mycompany.bluraystore.repository.MovieRepositoryInterface;
import org.mycompany.bluraystore.service.MovieServiceInterface;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        MovieController controller = context.getBean(MovieController.class);
        MovieServiceInterface service = context.getBean(MovieServiceInterface.class);
        MovieRepositoryInterface repository = context.getBean(MovieRepositoryInterface.class);

        controller.setService(service);
        service.setRepository(repository);
        controller.addUsingConsole();

    }
}
