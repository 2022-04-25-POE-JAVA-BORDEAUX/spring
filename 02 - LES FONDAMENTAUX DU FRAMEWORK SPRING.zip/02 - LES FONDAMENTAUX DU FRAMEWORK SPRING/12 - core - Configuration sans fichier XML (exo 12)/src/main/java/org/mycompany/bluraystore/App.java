package org.mycompany.bluraystore;

import org.mycompany.bluraystore.controller.MovieController;
import org.mycompany.bluraystore.repository.MovieRepositoryInterface;
import org.mycompany.bluraystore.service.MovieServiceInterface;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        MovieController controller = context.getBean(MovieController.class);
        controller.addUsingConsole();

    }
}
