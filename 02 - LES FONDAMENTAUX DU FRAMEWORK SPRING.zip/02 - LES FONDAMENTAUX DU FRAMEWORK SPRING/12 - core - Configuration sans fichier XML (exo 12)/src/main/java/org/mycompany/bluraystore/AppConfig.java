package org.mycompany.bluraystore;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan(basePackages = { "org.mycompany.bluraystore.controller", "org.mycompany.bluraystore.repository.file", "org.mycompany.bluraystore.service" })
@PropertySource("classpath:application.properties")
public class AppConfig {
}
