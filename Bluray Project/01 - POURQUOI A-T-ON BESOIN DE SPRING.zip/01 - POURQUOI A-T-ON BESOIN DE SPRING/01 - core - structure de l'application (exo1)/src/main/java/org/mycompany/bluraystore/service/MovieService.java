package org.mycompany.bluraystore.service;

import org.mycompany.bluraystore.entity.Movie;
import org.mycompany.bluraystore.repository.MovieRepository;

public class MovieService {

    private MovieRepository repository = new MovieRepository();

    public void registerMovie(Movie movie) {
        repository.createMovie(movie);
    }
}
