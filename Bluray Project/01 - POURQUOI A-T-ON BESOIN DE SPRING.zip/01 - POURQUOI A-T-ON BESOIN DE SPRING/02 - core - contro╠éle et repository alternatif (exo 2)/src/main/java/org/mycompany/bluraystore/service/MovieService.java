package org.mycompany.bluraystore.service;

import org.mycompany.bluraystore.entity.Movie;
import org.mycompany.bluraystore.repository.MovieRepository;
import org.mycompany.bluraystore.repository.MovieRepositoryWithText;

public class MovieService {

    // private MovieRepository repository = new MovieRepository();
    private MovieRepositoryWithText repository = new MovieRepositoryWithText();

    public void registerMovie(Movie movie) {
        repository.add(movie);
    }
}
