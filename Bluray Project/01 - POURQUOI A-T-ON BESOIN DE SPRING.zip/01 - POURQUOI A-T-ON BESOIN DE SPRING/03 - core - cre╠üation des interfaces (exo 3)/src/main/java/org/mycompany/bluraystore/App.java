package org.mycompany.bluraystore;

import org.mycompany.bluraystore.controller.MovieController;
import org.mycompany.bluraystore.entity.Movie;
import org.mycompany.bluraystore.service.MovieService;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        // Ancienne version de la partie 1
        /** String title, genre;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a title :");
        title = scanner.nextLine();

        System.out.println("Enter a genre :");
        genre = scanner.nextLine();

        Movie movie = new Movie();
        movie.setGenre(genre);
        movie.setTitle(title);

        MovieService service = new MovieService();
        service.registerMovie(movie);**/

        MovieController controller = new MovieController();
        controller.addUsingConsole();
    }
}
