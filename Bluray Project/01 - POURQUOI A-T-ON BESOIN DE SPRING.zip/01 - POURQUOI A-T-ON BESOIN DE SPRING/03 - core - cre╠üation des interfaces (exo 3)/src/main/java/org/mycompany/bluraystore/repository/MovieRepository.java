package org.mycompany.bluraystore.repository;

import org.mycompany.bluraystore.entity.Movie;

import java.util.ArrayList;
import java.util.List;

// changement opéré
public class MovieRepository implements MovieRepositoryInterface {

    private static List<Movie> movies = new ArrayList<>();

    public void add(Movie movie) {
        movies.add(movie);
        System.out.println("Movie called " + movie.getTitle() + " added ! ");
    }

}
