package org.mycompany.bluraystore;

import org.mycompany.bluraystore.controller.MovieController;
import org.mycompany.bluraystore.entity.Movie;
import org.mycompany.bluraystore.repository.MovieRepository;
import org.mycompany.bluraystore.service.MovieService;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        MovieController controller = new MovieController();

        // injections du service
        MovieService service = new MovieService();
        controller.setService(service);

        // injection du repository
        MovieRepository repository = new MovieRepository(); // or MovieRepositoryWithText
        service.setRepository(repository);

        controller.addUsingConsole();
    }
}
