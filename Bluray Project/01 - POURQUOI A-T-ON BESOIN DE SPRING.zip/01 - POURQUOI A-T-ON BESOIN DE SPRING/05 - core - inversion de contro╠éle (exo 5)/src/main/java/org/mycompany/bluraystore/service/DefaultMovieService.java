package org.mycompany.bluraystore.service;

import org.mycompany.bluraystore.entity.Movie;
import org.mycompany.bluraystore.repository.MovieRepositoryInterface;

public class DefaultMovieService implements MovieServiceInterface {

    // private MovieRepository repository = new MovieRepository();
    // changement opéré
    private MovieRepositoryInterface repository;

    public void registerMovie(Movie movie) {
        repository.add(movie);
    }

    public MovieRepositoryInterface getRepository() {
        return repository;
    }

    public void setRepository(MovieRepositoryInterface repository) {
        this.repository = repository;
    }
}
