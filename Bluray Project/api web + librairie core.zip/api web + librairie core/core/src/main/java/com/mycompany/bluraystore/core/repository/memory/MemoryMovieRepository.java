package com.mycompany.bluraystore.core.repository.memory;

import com.mycompany.bluraystore.core.entity.Movie;
import com.mycompany.bluraystore.core.repository.MovieRepositoryInterface;

import java.util.ArrayList;
import java.util.List;

//@Repository
public class MemoryMovieRepository implements MovieRepositoryInterface {

    private static List<Movie> movies = new ArrayList<>();

    public void add(Movie movie) {
        movies.add(movie);
        System.out.println("Movie called " + movie.getTitle() + " has been added !");
    }

    @Override
    public List<Movie> list() {
        return movies;
    }

    @Override
    public Movie getById(long id) {
        return movies.stream().filter(movie -> movie.getId() == id).findFirst().get();
    }

}
