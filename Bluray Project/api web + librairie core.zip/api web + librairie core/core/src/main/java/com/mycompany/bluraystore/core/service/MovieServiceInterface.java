package com.mycompany.bluraystore.core.service;

import com.mycompany.bluraystore.core.entity.Movie;

import java.util.List;

public interface MovieServiceInterface {

    public void registerMovie(Movie movie);
    public List<Movie> getMovieList();
    public Movie getMovieById(long id);
}
