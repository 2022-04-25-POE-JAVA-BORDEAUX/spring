package com.mycompany.bluraystore;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan(basePackages = { "com.mycompany.bluraystore.controller", "com.mycompany.bluraystore.service", "com.mycompany.bluraystore.repository.file" })
@PropertySource("classpath:application.properties")
@ImportResource("classpath:applicationContext.xml")
public class AppConfig {



}
