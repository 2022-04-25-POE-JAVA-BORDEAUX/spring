package com.mycompany.bluraystore.repository;

import com.mycompany.bluraystore.entity.Movie;

public interface MovieRepositoryInterface {

    public void add(Movie movie);
}
