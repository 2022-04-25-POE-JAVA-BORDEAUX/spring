package com.company.invoice;

import com.company.invoice.entity.Invoice;
import com.company.invoice.service.InvoiceService;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App1
{



    public static void main( String[] args )
    {
        // on va demander à l'utlisateur quel est le nom du client pour lequel il souhaite créer la facture
        Scanner scanner = new Scanner(System.in);
        System.out.println("Customer name :");
        String customerName = scanner.nextLine();
        Invoice newInvoice = new Invoice();
        newInvoice.setCustomerInvoice(customerName);
        InvoiceService service = new InvoiceService();
        service.createInvoice(newInvoice);

    }
}
