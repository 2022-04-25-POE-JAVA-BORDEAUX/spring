package com.company.invoice.controller;

import com.company.invoice.entity.Invoice;
import com.company.invoice.service.InvoiceService;

import java.util.Scanner;

public class InvoiceController {

    public void createInvoiceUsingConsole() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Customer name :");
        String customerName = scanner.nextLine();
        Invoice newInvoice = new Invoice();
        newInvoice.setCustomerInvoice(customerName);

        InvoiceService service = new InvoiceService();
        service.createInvoice(newInvoice);
    }

}
