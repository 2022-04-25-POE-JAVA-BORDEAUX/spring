package com.company.invoice.controller;

import com.company.invoice.entity.Invoice;
import com.company.invoice.service.InvoiceService;
import com.company.invoice.service.InvoiceServiceNewClient;

import java.util.Scanner;

public class InvoiceControllerNewClient {

    // je vais faire ici comme ci j'avais une interface graphique
    public void createInvoiceUsingWebPage() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Customer name :");

        String customerName = "Nom du nouveau client"; // on simulte qu'un formulaire nous a renvoyé un nom de client
        Invoice newInvoice = new Invoice();
        newInvoice.setCustomerInvoice(customerName);

        InvoiceServiceNewClient service = new InvoiceServiceNewClient();
        service.createInvoice(newInvoice);
    }

}
