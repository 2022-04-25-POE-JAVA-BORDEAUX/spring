package com.company.invoice.repository;

import com.company.invoice.entity.Invoice;

public class InvoiceRepositoryNewClient {

    // ici on devrait avoir un petit bout de code JDBC pour enregistrer ça en BDD
    public void createInvoice(Invoice invoice) {


        // pas besoin de coder cette partie c'est juste à titre indicatif

        /** try{
            Class.forName("oracle.jdbc.driver.OracleDriver");

            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");

            PreparedStatement stmt=con.prepareStatement("insert into Invoices values(?,?)");
            stmt.setInt(1,101);//1 specifies the first parameter in the query
            stmt.setString(2,"Ratan");

            int i=stmt.executeUpdate();
            System.out.println(i+" records inserted");

            con.close();

        }catch(Exception e){ System.out.println(e);}



    } **/


    }

}
