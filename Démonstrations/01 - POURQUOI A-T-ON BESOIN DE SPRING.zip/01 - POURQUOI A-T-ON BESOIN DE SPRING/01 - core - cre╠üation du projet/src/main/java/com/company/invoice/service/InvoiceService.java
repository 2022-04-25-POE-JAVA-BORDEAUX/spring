package com.company.invoice.service;

import com.company.invoice.entity.Invoice;
import com.company.invoice.repository.InvoiceRepository;

public class InvoiceService {

    private static long lastNumber = 0L;

    // A encapsuler après avoir mis en place les classes Invoice et InvoiceRepository
    private InvoiceRepository repository = new InvoiceRepository();

    public void createInvoice(Invoice invoice) {
        invoice.setNumber(String.valueOf(++lastNumber));
        repository.createInvoice(invoice);
    }
}
