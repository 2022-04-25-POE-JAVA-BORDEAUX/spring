package com.company.invoice.service;

import com.company.invoice.entity.Invoice;
import com.company.invoice.repository.InvoiceRepository;

public class InvoiceServiceNewClient {

    private static long lastNumber = 0L;

    // A encapsuler après avoir mis en place les classes Invoice et InvoiceRepository
    private InvoiceRepository repository = new InvoiceRepository();

    public void createInvoice(Invoice invoice) {
        // j'ai ajouté un préfixe avant le numéro de la facture
        invoice.setNumber("INV_" + String.valueOf(++lastNumber));
        repository.createInvoice(invoice);
    }
}
