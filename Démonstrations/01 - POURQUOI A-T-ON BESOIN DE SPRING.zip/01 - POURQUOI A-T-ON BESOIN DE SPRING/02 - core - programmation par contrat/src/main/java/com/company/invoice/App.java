package com.company.invoice;

import com.company.invoice.controller.InvoiceController;
import com.company.invoice.controller.InvoiceControllerNewClient;
import com.company.invoice.entity.Invoice;
import com.company.invoice.repository.InvoiceRepository;
import com.company.invoice.service.InvoiceService;
import com.company.invoice.service.InvoiceServiceNewClient;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App 
{

    public static void main( String[] args )
    {
        System.out.println("Dans quelle configuration êtes-vous?");
        Scanner scanner = new Scanner(System.in);
        int config = scanner.nextInt();

        if (config ==1) {
            InvoiceController controller = new InvoiceController();
            // penser à bien renommer ici l'appel de la méthode
            controller.createInvoice();
        } else {
            InvoiceControllerNewClient controller = new InvoiceControllerNewClient();
            // penser à bien renommer ici l'appel de la méthode
            controller.createInvoice();
        }


    }
}
