package com.company.invoice.controller;

import com.company.invoice.entity.Invoice;
import com.company.invoice.service.InvoiceServiceInterface;
import com.company.invoice.service.InvoiceServiceNewClient;

import java.util.Scanner;

public class InvoiceControllerNewClient implements InvoiceControllerInterface {

    // on va faire comme-ci interface graphique
    // je n'instancie plus le service ici mais fait référence à l'interface
    private InvoiceServiceInterface service;

    public void createInvoice() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Customer name :");

        String customerName = "Nom du nouveau client";
        Invoice newInvoice = new Invoice();
        newInvoice.setCustomerInvoice(customerName);

        service.createInvoice(newInvoice);
    }

}
