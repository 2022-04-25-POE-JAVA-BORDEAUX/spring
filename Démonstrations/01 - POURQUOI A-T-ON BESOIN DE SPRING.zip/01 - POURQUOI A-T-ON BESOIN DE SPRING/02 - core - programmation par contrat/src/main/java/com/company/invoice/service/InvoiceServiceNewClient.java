package com.company.invoice.service;

import com.company.invoice.entity.Invoice;
import com.company.invoice.repository.InvoiceRepository;
import com.company.invoice.repository.InvoiceRepositoryInterface;

public class InvoiceServiceNewClient implements InvoiceServiceInterface{

    private static long lastNumber = 0L;

    // Je fais maintenant référence à mon interface
    private InvoiceRepositoryInterface repository;

    public void createInvoice(Invoice invoice) {
        // j'ai ajouté un préfixe avant le numéro de la facture
        invoice.setNumber("INV_" + String.valueOf(++lastNumber));
        repository.createInvoice(invoice);
    }
}
