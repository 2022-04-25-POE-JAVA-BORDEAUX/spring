package com.company.invoice;

import com.company.invoice.controller.InvoiceController;
import com.company.invoice.controller.InvoiceControllerNewClient;
import com.company.invoice.controller.InvoiceControllerThirdClient;
import com.company.invoice.entity.Invoice;
import com.company.invoice.repository.InvoiceRepository;
import com.company.invoice.repository.InvoiceRepositoryNewClient;
import com.company.invoice.service.InvoiceService;
import com.company.invoice.service.InvoiceServiceNewClient;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App 
{

    public static void main( String[] args )
    {
        System.out.println("Dans quelle configuration êtes-vous?");
        Scanner scanner = new Scanner(System.in);
        int config = scanner.nextInt();

        if (config ==1) {
            InvoiceController controller = new InvoiceController();

            // je vais gérer ici l'injection de dépendances
            // le controller a besoin du service
            InvoiceService invoiceService = new InvoiceService();
            controller.setService(invoiceService);

            // le service a besoin du repository
            InvoiceRepository repository = new InvoiceRepository();
            invoiceService.setRepository(repository);

            controller.createInvoice();

        } else if (config == 1) {
            InvoiceControllerNewClient controller = new InvoiceControllerNewClient();

            // pour le deuxième scénario c'est le même principe sauf que les dépendances sont différentes
            // le controller a besoin du service
            InvoiceServiceNewClient invoiceService = new InvoiceServiceNewClient();
            controller.setService(invoiceService);

            // le service a besoin du repository
            InvoiceRepositoryNewClient repository = new InvoiceRepositoryNewClient();
            invoiceService.setRepository(repository);

            controller.createInvoice();

            // Ici on va gérer le troisième client avec son système de scanner

        } else if (config == 3 ) {

            // Comme expliqué il utilise son propre controller
            InvoiceControllerThirdClient controller = new InvoiceControllerThirdClient();

            // le service du client 1
            InvoiceService invoiceService = new InvoiceService();
            controller.setService(invoiceService);

            // et pour la partie repository il peut utiliser celle du client 1 ou 2
            InvoiceRepositoryNewClient repository = new InvoiceRepositoryNewClient();
            invoiceService.setRepository(repository);

            controller.createInvoice();
        }


    }
}
