package com.company.invoice.controller;

import com.company.invoice.entity.Invoice;
import com.company.invoice.service.InvoiceService;
import com.company.invoice.service.InvoiceServiceInterface;

import java.util.Scanner;

public class InvoiceController implements InvoiceControllerInterface {

    private InvoiceServiceInterface service;

    public void createInvoice() {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Customer name :");
        String customerName = scanner.nextLine();

        Invoice newInvoice = new Invoice();
        newInvoice.setCustomerInvoice(customerName);

        service.createInvoice(newInvoice);
    }

    // ajouter les getters/setters
    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }

}
