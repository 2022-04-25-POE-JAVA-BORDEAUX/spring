package com.company.invoice.controller;

public interface InvoiceControllerInterface {

    public void createInvoice();

}
