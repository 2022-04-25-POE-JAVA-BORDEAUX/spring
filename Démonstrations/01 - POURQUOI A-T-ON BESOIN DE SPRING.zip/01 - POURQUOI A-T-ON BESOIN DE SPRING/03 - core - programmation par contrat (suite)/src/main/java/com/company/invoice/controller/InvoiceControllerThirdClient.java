package com.company.invoice.controller;

import com.company.invoice.entity.Invoice;
import com.company.invoice.service.InvoiceServiceInterface;

public class InvoiceControllerThirdClient implements InvoiceControllerInterface {

    // je vais également avoir besoin de mon interfaces
    private InvoiceServiceInterface service;

    @Override
    public void createInvoice() {

        // ici on va utiliser une douchette
        System.out.println("Je passe par ici donc j'utilise un scanner pour générer ma facture");
        Invoice invoice = new Invoice();
        invoice.setCustomerInvoice("SFR");
        service.createInvoice(invoice);
    }


    // des getters et des setters

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }
}
