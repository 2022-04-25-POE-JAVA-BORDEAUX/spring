package com.company.invoice.service;

import com.company.invoice.entity.Invoice;
import com.company.invoice.repository.InvoiceRepository;
import com.company.invoice.repository.InvoiceRepositoryInterface;

public class InvoiceService implements InvoiceServiceInterface {

    private static long lastNumber = 0L;

    private InvoiceRepositoryInterface repository;

    public void createInvoice(Invoice invoice) {
        invoice.setNumber(String.valueOf(++lastNumber));
        repository.createInvoice(invoice);
    }

    // ajout des getters/setters
    public InvoiceRepositoryInterface getRepository() {
        return repository;
    }

    public void setRepository(InvoiceRepositoryInterface repository) {
        this.repository = repository;
    }
}
