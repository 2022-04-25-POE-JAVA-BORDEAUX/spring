package com.company.invoice.service;

import com.company.invoice.entity.Invoice;

public interface InvoiceServiceInterface {

    public void createInvoice(Invoice invoice);
}
