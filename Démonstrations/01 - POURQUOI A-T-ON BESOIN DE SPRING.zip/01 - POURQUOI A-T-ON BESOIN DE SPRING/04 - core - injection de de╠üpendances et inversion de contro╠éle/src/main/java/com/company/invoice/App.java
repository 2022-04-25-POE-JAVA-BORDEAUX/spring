package com.company.invoice;

import com.company.invoice.controller.InvoiceControllerInterface;
import com.company.invoice.repository.InvoiceRepositoryInterface;
import com.company.invoice.service.InvoiceServiceInterface;

import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App
{

    public static void main( String[] args )
    {


        Scanner scanner = new Scanner(System.in);
        System.out.println("Quelle est la class du controller?");
        String controllerName = scanner.nextLine();

        System.out.println("Quelle est la classe du service?");
        String serviceName = scanner.nextLine();

        System.out.println("Quelle est la classe du repository?");
        String repositoryName = scanner.nextLine();

        InvoiceControllerInterface controllerI = null;
        InvoiceServiceInterface serviceI = null;
        InvoiceRepositoryInterface repoI = null;

        // utilisons les principes de reflexivité pour instancier dynamiquement nos classes
        // donc plus besoin de switch case

        try {
            controllerI = (InvoiceControllerInterface) Class.forName(controllerName).getDeclaredConstructor().newInstance();
            serviceI = (InvoiceServiceInterface) Class.forName(serviceName).getDeclaredConstructor().newInstance();
            repoI = (InvoiceRepositoryInterface) Class.forName(repositoryName).getDeclaredConstructor().newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        // Rentrer ces informations

        // com.company.invoice.controller.InvoiceControllerScanner
        // com.company.invoice.service.InvoiceServicePrefix
        // com.company.invoice.repository.InvoiceRepositoryDataBase

        // on set maintenant le service et le repository
        controllerI.setService(serviceI);
        serviceI.setRepository(repoI);

        controllerI.createInvoice();
    }
}
