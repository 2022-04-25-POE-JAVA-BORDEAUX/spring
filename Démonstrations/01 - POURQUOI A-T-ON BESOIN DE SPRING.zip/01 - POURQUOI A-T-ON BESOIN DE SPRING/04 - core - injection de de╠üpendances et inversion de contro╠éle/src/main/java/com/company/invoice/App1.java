package com.company.invoice;

import com.company.invoice.controller.InvoiceControllerInterface;
import com.company.invoice.controller.InvoiceControllerKeyBoard;
import com.company.invoice.controller.InvoiceControllerWeb;
import com.company.invoice.controller.InvoiceControllerScanner;
import com.company.invoice.repository.InvoiceRepositoryInMemory;
import com.company.invoice.repository.InvoiceRepositoryDataBase;
import com.company.invoice.repository.InvoiceRepositoryInterface;
import com.company.invoice.service.InvoiceServiceInterface;
import com.company.invoice.service.InvoiceServiceNumber;
import com.company.invoice.service.InvoiceServicePrefix;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App1
{

    public static void main( String[] args )
    {


        Scanner scanner = new Scanner(System.in);
        System.out.println("Quelle est le type de controller? (keyboard, web, scanner)");
        String controller = scanner.nextLine();

        System.out.println("Quelle est le type de service? (number, prefix)");
        String service = scanner.nextLine();

        System.out.println("Quelle est le type de repository? (memory, bdd)");
        String repository = scanner.nextLine();

        InvoiceControllerInterface controllerI = null;
        InvoiceServiceInterface serviceI = null;
        InvoiceRepositoryInterface repoI = null;

        // CONTROLLER
        switch (controller) {

            case "keyboard":
                controllerI = new InvoiceControllerKeyBoard();
                break;
            case "web":
                controllerI = new InvoiceControllerWeb();
                break;
            case "scanner":
                controllerI = new InvoiceControllerScanner();
                break;
        }

        // SERVICE
        switch (service) {

            case "number":
                serviceI = new InvoiceServiceNumber();
                break;
            case "prefix":
                serviceI = new InvoiceServicePrefix();
                break;
        }

        // REPOSITORY
        switch (repository) {

            case "memory":
                repoI = new InvoiceRepositoryInMemory();
                break;
            case "bdd":
                repoI = new InvoiceRepositoryDataBase();
                break;
        }

        // on set maintenant le service et le repository
        controllerI.setService(serviceI);
        serviceI.setRepository(repoI);

        controllerI.createInvoice();
    }
}
