package com.company.invoice.service;

import com.company.invoice.entity.Invoice;
import com.company.invoice.repository.InvoiceRepositoryInterface;

public interface InvoiceServiceInterface {

    public void createInvoice(Invoice invoice);
    public void setRepository(InvoiceRepositoryInterface repository);

}
