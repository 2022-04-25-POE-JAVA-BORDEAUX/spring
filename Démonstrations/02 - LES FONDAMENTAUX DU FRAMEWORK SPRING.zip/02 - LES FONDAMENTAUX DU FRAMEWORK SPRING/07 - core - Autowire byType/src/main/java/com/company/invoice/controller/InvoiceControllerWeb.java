package com.company.invoice.controller;

import com.company.invoice.entity.Invoice;
import com.company.invoice.service.InvoiceServiceInterface;

import java.util.Scanner;

public class InvoiceControllerWeb implements InvoiceControllerInterface {

    // je n'instancie plus le service ici mais fait référence à l'interface
    private InvoiceServiceInterface service;

    public void createInvoice() {
        Scanner scanner = new Scanner(System.in);
        //System.out.println("Customer name :");
        //String customerName = scanner.nextLine();
        // Rappelez-vous, pour cette configuration on fait comme-ci l'info nous venez d'un formulaire donc on l'a mis directement le nom du client ic
        String customerName = "Nom du nouveau client";
        Invoice newInvoice = new Invoice();
        newInvoice.setCustomerInvoice(customerName);

        service.createInvoice(newInvoice);
    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }
}
