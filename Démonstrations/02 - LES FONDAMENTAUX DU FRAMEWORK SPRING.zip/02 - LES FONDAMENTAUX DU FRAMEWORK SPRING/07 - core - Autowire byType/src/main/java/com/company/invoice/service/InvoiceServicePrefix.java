package com.company.invoice.service;

import com.company.invoice.entity.Invoice;
import com.company.invoice.repository.InvoiceRepositoryInterface;

import java.io.File;

public class InvoiceServicePrefix implements InvoiceServiceInterface{

    // j'ai enlevé le static et je vais passer une valeur à lastNumber pour que ce soit configurable et non en dur
    private long lastNumber;

    // je vais rendre paramétrable aussi le prefix que je mets avant les numéros de factures
    private String prefix;

    private InvoiceRepositoryInterface repository;

    // Autre exemple si je souhaite récupére une valeur de type File
    private File file;

    public void createInvoice(Invoice invoice) {
        // du coup ici le prefix n'est plus en dure
        invoice.setNumber(prefix + String.valueOf(++lastNumber));
        repository.createInvoice(invoice);
    }

    public InvoiceRepositoryInterface getRepository() {
        return repository;
    }

    public void setRepository(InvoiceRepositoryInterface repository) {
        this.repository = repository;
    }


    // ne pas oublier d'ajouter des getters et des setters pour les attributs lastNumber et prefix car on va leur passé des valeurs plus tard


    public long getLastNumber() {
        return lastNumber;
    }

    public void setLastNumber(long lastNumber) {
        this.lastNumber = lastNumber;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }
}
