package com.company.invoice;

import com.company.invoice.controller.InvoiceControllerInterface;
import com.company.invoice.repository.InvoiceRepositoryInterface;
import com.company.invoice.service.InvoiceServiceInterface;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App
{

    public static void main( String[] args )
    {

        // instancie un conteneur léger qui trouve dans mon classe path qui s'appel ApplicationContext.xml
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml"); // on est à la racine du classPath car le répetoire est à disposition de notre classpath
        // ce qui se passe ci-dessous c'est que spring va instancier tous les objets et les mettre en relation et conserver tout cela en mémoire a partir de la variable context

        // pour récupérer un des objets instanciés (ici on veut le controller)
        // si je connais l'identifiant :
        // context.getBean("invoiceController"); mais ici on a pas d'id dans ApplicationContext.xml

        // on peut donc préciser la classe :
        InvoiceControllerInterface controller = context.getBean(InvoiceControllerInterface.class); // pour éviter d'avoir un lien direct avec la classe et de devoir modifier mon code plus tard je précise l'interface
        // cela nous renvoit un objet

        // TADAAA

        controller.createInvoice();
    }
}
