package com.company.invoice.controller;

import com.company.invoice.service.InvoiceServiceInterface;

public interface InvoiceControllerInterface {

    public void createInvoice();
    public void setService(InvoiceServiceInterface service);

}
