package com.company.invoice;

import com.company.invoice.controller.InvoiceControllerInterface;
import com.company.invoice.repository.InvoiceRepositoryInterface;
import com.company.invoice.service.InvoiceServiceInterface;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App
{
    public static void main( String[] args )
    {
        // ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        // On ne passera plus par le xml mais par notre classe AppConfig
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        InvoiceControllerInterface controller = context.getBean(InvoiceControllerInterface.class);
        controller.createInvoice();
    }
}
