package com.company.invoice;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan(basePackages = {"com.company.invoice.controller.web", "com.company.invoice.service.prefix", "com.company.invoice.repository.memory"})
//@PropertySource("classpath:application.properties") ici j'importe le fichier dans mon xml
@ImportResource("classpath:applicationContext.xml") // ici du coup en complément j'utilise mon fichier xml
public class AppConfig {

}
