package com.company.invoice;

import com.company.invoice.controller.InvoiceControllerInterface;
import com.company.invoice.repository.InvoiceRepositoryInterface;
import com.company.invoice.service.InvoiceServiceInterface;
import com.company.invoice.service.prefix.InvoiceServicePrefix;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
@Configuration
// @ComponentScan(basePackages = {"com.company.invoice.controller.web", "com.company.invoice.service.prefix", "com.company.invoice.repository.memory"})
// A configurer de cette façon quand on va vouloir retourner un service avec notre méthode de classe dans App
@ComponentScan(basePackages = {"com.company.invoice.controller.web", "com.company.invoice.repository.memory"})
@PropertySource("classpath:application.properties")
public class App
{
    public static void main( String[] args )
    {
        // Maintenant la config se fait directement dans la classe Main
        ApplicationContext context = new AnnotationConfigApplicationContext(App.class);
        InvoiceControllerInterface controller = context.getBean(InvoiceControllerInterface.class);
        controller.createInvoice();
    }

    // méthode qui va nous retourner un service
    // j'ai un retour de type InvoiceServiceInterface car les services implémentent cette interface

    @Bean
    public InvoiceServiceInterface configureInvoiceService() {
        return new InvoiceServicePrefix();
    }
}
