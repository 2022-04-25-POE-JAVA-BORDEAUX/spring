package com.company.invoice;

import com.company.invoice.controller.InvoiceControllerInterface;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class AppV1WithTwoAppConfig
{
    public static void main( String[] args )
    {
        // ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        // On ne passera plus par le xml mais par notre classe AppConfig
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class, AppConfigPropertySource.class);
        InvoiceControllerInterface controller = context.getBean(InvoiceControllerInterface.class);
        controller.createInvoice();
    }
}
