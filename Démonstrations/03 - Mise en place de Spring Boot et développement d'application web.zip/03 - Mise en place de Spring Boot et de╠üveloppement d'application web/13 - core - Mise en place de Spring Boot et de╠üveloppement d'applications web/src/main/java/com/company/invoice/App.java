package com.company.invoice;

import com.company.invoice.controller.InvoiceControllerInterface;
import com.company.invoice.repository.InvoiceRepositoryInterface;
import com.company.invoice.service.InvoiceServiceInterface;
import com.company.invoice.service.prefix.InvoiceServicePrefix;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
@SpringBootApplication
// A commenter quand tu expliques que SpringBoot le trouve automatiquement si il s'appel classpath:application.properties
//@PropertySource("classpath:application.properties")
public class App
{
    public static void main( String[] args )
    {
        // ApplicationContext context = new AnnotationConfigApplicationContext(App.class);

        // très similaire à new AnnotationConfigApplicationContext
        ApplicationContext context = SpringApplication.run(App.class);
        InvoiceControllerInterface controller = context.getBean(InvoiceControllerInterface.class);
        controller.createInvoice();
    }

}
