package com.company.invoice.controller.web;

import com.company.invoice.controller.InvoiceControllerInterface;
import com.company.invoice.entity.Invoice;
import com.company.invoice.service.InvoiceServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Scanner;

// @Component
@Controller
public class InvoiceControllerWeb implements InvoiceControllerInterface {

    @Autowired
    private InvoiceServiceInterface service;

    public void createInvoice() {
        Scanner scanner = new Scanner(System.in);
          String customerName = "Nom du nouveau client";
        Invoice newInvoice = new Invoice();
        newInvoice.setCustomerInvoice(customerName);

        service.createInvoice(newInvoice);
    }

    @RequestMapping("/invoice-home")
    public String displayHome() {
        System.out.println("La méthode displayHome a bien été appelée !");
        return "";
    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }
}
