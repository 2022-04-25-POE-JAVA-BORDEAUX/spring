package com.company.invoice.repository;

import com.company.invoice.entity.Invoice;

public interface InvoiceRepositoryInterface {

    void createInvoice(Invoice invoice);

}
