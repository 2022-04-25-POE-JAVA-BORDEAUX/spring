package com.mycompany.invoice.core.controller.keyboard;

import com.mycompany.invoice.core.controller.InvoiceControllerInterface;
import com.mycompany.invoice.core.entity.Invoice;
import com.mycompany.invoice.core.service.InvoiceServiceInterface;

import java.util.Scanner;

//@Controller
public class InvoiceControllerKeyBoard implements InvoiceControllerInterface {

    private InvoiceServiceInterface service;

    public String createInvoice(Invoice invoice) {

        // je permets à l'utilisateur de faire une saisie
        Scanner scanner = new Scanner(System.in);
        System.out.println("Customer name :");
        String customerName = scanner.nextLine();
        invoice = new Invoice();
        invoice.setCustomerInvoice(customerName);


        service.createInvoice(invoice);

        return null;

    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }
}
