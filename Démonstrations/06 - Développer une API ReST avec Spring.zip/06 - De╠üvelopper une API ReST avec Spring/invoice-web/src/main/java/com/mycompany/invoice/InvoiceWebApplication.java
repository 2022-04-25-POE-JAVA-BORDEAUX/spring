package com.mycompany.invoice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvoiceWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(InvoiceWebApplication.class, args);
	}

}
