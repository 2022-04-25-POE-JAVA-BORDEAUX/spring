package com.mycompany.invoice.invoiceweb.controller;

import com.mycompany.invoice.core.controller.InvoiceControllerInterface;
import com.mycompany.invoice.core.controller.InvoiceControllerInterfacev1;
import com.mycompany.invoice.core.entity.Invoice;
import com.mycompany.invoice.core.service.InvoiceServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

// @Component
@RequestMapping("/invoice")
public class InvoiceControllerWebv4 implements InvoiceControllerInterfacev1 {

    @Autowired
    private InvoiceServiceInterface service;

    @PostMapping("")
    public void createInvoice() {

        String customerName = "Nike"; // je simule que j'ai reçu cette donnée depuis mon formulaire
        Invoice newInvoice = new Invoice();
        newInvoice.setCustomerInvoice(customerName);

        service.createInvoice(newInvoice);
    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }

    @RequestMapping("/home")
    public String displayHome(Model model) {
        model.addAttribute("invoices", service.getInvoiceList());
        return "invoice-home";
    }

    @RequestMapping("/{id}")
    public String displayInvoice(@PathVariable("id") String number, Model model) {
        model.addAttribute("invoice", service.getInvoiceByNumber(number));
        return "invoice-details";
    }

    @RequestMapping("/create-form")
    public String displayInvoiceCreateForm() {
        return "invoice-create-form";
    }
}
