package com.mycompany.invoice.invoiceweb.controller;

import com.mycompany.invoice.core.controller.InvoiceControllerInterface;
import com.mycompany.invoice.core.entity.Invoice;
import com.mycompany.invoice.core.service.InvoiceServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

// @Component
//@Controller
//@RequestMapping("/invoice")
public class InvoiceControllerWebv6 implements InvoiceControllerInterface {

    @Autowired
    private InvoiceServiceInterface service;

    @PostMapping("")
    //public String createInvoice(@ModelAttribute("invoice") Invoice invoice) {
    // t'es pas obligé de donné un nom au model attribute
    // ici il va s'appeler invoice par défaut car prend le nom de l'argument
    public String createInvoice(@ModelAttribute Invoice invoice) {

        String customerName = "Nike";
        invoice = new Invoice();
        invoice.setCustomerInvoice(customerName);

        service.createInvoice(invoice);

        return "invoice-created";
    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }

    @GetMapping("/home")
    public String displayHome(Model model) {
        model.addAttribute("invoices", service.getInvoiceList());
        return "invoice-home";
    }

    @GetMapping("/{id}")
    public String displayInvoice(@PathVariable("id") String number, Model model) {
        model.addAttribute("invoice", service.getInvoiceByNumber(number));
        return "invoice-details";
    }

    @GetMapping("/create-form")
    public String displayInvoiceCreateForm(@ModelAttribute Invoice invoice) {
        return "invoice-create-form";
    }
}
