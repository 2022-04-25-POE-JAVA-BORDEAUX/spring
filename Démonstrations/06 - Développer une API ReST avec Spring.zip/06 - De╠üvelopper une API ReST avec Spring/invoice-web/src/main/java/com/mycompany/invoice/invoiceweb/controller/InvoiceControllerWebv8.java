package com.mycompany.invoice.invoiceweb.controller;

import com.mycompany.invoice.core.service.InvoiceServiceInterface;
import com.mycompany.invoice.invoiceweb.form.InvoiceForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

// @Component
// @Controller
// @RequestMapping("/invoice")
public class InvoiceControllerWebv8 {

    @Autowired
    private InvoiceServiceInterface service;

    /*
    @PostMapping("")
    public String createInvoice(@Valid @ModelAttribute InvoiceForm invoiceForm, BindingResult results) {

        if(results.hasErrors()) {
            return "invoice-create-form";
        }

        // Je peux faire ça à la main car j'ai pas beaucoup de champs
        Invoice invoice = new Invoice();
        invoice.setCustomerInvoice(invoiceForm.getCustomerInvoice());
        invoice.setNumber(invoiceForm.getNumber());

        service.createInvoice(invoice);

        return "invoice-created";
    }*/

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }

    /*
    @GetMapping("/home")
    public String displayHome(Model model) {
        model.addAttribute("invoices", service.getInvoiceList());
        return "invoice-home";
    }*/

    /*
    @GetMapping("/{id}")
    public String displayInvoice(@PathVariable("id") String number, Model model) {
        model.addAttribute("invoice", service.getInvoiceByNumber(number));
        return "invoice-details";
    }*/


    @GetMapping("/create-form")
    public String displayInvoiceCreateForm(@ModelAttribute InvoiceForm invoiceForm) {
        return "invoice-create-form";
    }
}
