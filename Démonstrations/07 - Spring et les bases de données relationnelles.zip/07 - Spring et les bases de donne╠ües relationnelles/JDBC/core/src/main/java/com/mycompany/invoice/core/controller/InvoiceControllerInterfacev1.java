package com.mycompany.invoice.core.controller;

import com.mycompany.invoice.core.service.InvoiceServiceInterface;

public interface InvoiceControllerInterfacev1 {

    public void createInvoice();

    public void setService(InvoiceServiceInterface service);
}
