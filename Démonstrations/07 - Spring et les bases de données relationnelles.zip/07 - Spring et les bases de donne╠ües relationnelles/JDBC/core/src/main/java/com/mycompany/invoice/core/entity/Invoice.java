package com.mycompany.invoice.core.entity;

public class Invoice {

    private String number;
    private String customerInvoice;
    private String orderNumber;

    public Invoice(String number, String customerInvoice) {
        this.number = number;
        this.customerInvoice = customerInvoice;
    }

    public Invoice(String number, String customerInvoice, String orderNumber) {
        this.number = number;
        this.customerInvoice = customerInvoice;
        this.orderNumber = orderNumber;
    }

    public Invoice() {

    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getCustomerInvoice() {
        return customerInvoice;
    }

    public void setCustomerInvoice(String customerInvoice) {
        this.customerInvoice = customerInvoice;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }
}
