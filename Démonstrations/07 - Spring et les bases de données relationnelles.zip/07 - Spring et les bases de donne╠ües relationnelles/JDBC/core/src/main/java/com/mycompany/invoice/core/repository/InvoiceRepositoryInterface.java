package com.mycompany.invoice.core.repository;

import com.mycompany.invoice.core.entity.Invoice;

import java.util.List;

public interface InvoiceRepositoryInterface {

    public Invoice createInvoice(Invoice invoice);
    public List<Invoice> list();
    public Invoice getById(String number);

}
