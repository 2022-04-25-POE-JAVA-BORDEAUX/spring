package com.mycompany.invoice.core.repository.database;

import com.mycompany.invoice.core.repository.InvoiceRepositoryInterface;
import com.mycompany.invoice.core.entity.Invoice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;

@Repository
public class InvoiceRepositoryDatabase implements InvoiceRepositoryInterface {

    // JdbcTemplate va effectuer les requêtes
    // sans qu'on ai rien a faire
    // il va exploiter la datasource
    // recuperer une connexion
    // et gérer les différentes erreurs
    @Autowired
    private JdbcTemplate jdbcTemplate;


    @Override
    public Invoice createInvoice(Invoice invoice) {
        // méthode générique pour modifier une donnée en bdd


        KeyHolder kh = new GeneratedKeyHolder();

        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement("INSERT INTO INVOICE (CUSTOMER_NAME, ORDER_NUMBER) VALUES (?,?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, invoice.getCustomerInvoice());
            ps.setString(2, invoice.getOrderNumber());

            return ps;
        }, kh);

        invoice.setNumber(kh.getKey().toString());

        return invoice;

    }

    @Override
    public List<Invoice> list() {

        // Retourner les factureq que l'on a en BDD

        return jdbcTemplate.query("SELECT INVOICE_NUMBER, CUSTOMER_NAME FROM INVOICE",
                (rs, rownum) -> new Invoice(String.valueOf(rs.getLong("INVOICE_NUMBER")), rs.getString("CUSTOMER_NAME") ));

        // on a utilisé une expression lambda pour retourner pour chaque donnée dans mon resultSet
        // un objet de type Invoice
    }

    @Override
    public Invoice getById(String number) {

        return jdbcTemplate.queryForObject("SELECT INVOICE_NUMBER, CUSTOMER_NAME, ORDER_NUMBER FROM INVOICE WHERE INVOICE_NUMBER = ?",
                // dans la ligne ci-dessous ce sont les paramètres de ma requête
                new Object[]{number},
                (rs, rownum) -> new Invoice(
                        String.valueOf(rs.getLong("INVOICE_NUMBER")),
                        rs.getString("CUSTOMER_NAME"),
                        rs.getString("ORDER_NUMBER")  ));

    }
}
