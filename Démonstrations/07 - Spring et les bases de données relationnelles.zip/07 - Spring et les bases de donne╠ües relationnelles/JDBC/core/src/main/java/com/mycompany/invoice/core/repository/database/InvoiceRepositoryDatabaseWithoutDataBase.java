package com.mycompany.invoice.core.repository.database;

import com.mycompany.invoice.core.entity.Invoice;
import com.mycompany.invoice.core.repository.InvoiceRepositoryInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

//@Repository
public class InvoiceRepositoryDatabaseWithoutDataBase implements InvoiceRepositoryInterface {


    @Override
    public Invoice createInvoice(Invoice invoice) {
         return null;
    }

    @Override
    public List<Invoice> list() {

        Invoice invoice1 = new Invoice();
        invoice1.setCustomerInvoice("Sam");
        invoice1.setNumber("1");

        Invoice invoice2 = new Invoice();
        invoice2.setCustomerInvoice("Tom");
        invoice2.setNumber("2");

        return List.of(invoice1, invoice2); // list immuable
    }

    @Override
    public Invoice getById(String number) {

        // on va simuler une facture
        Invoice invoice1 = new Invoice();
        invoice1.setCustomerInvoice("Sam");
        invoice1.setNumber(number);
        invoice1.setOrderNumber("ON_002");

        return invoice1;
    }
}
