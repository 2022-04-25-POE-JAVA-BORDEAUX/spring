package com.mycompany.invoice.core.repository.memory;

import com.mycompany.invoice.core.repository.InvoiceRepositoryInterface;
import com.mycompany.invoice.core.entity.Invoice;

import java.util.ArrayList;
import java.util.List;


public class InvoiceRepositoryMemory implements InvoiceRepositoryInterface {

    public static List<Invoice> invoices = new ArrayList<>();

    @Override
    public Invoice createInvoice(Invoice invoice) {
        invoices.add(invoice);
        System.out.println("Invoice added with number " + invoice.getNumber() + " for customer : " + invoice.getCustomerInvoice());
        return invoice;
    }

    @Override
    public List<Invoice> list() {
        throw new UnsupportedOperationException();
    }

    @Override
    public Invoice getById(String number) {
        throw new UnsupportedOperationException(); // on dépanne avec ça mais dans la vraie vie on aurait renvoyé quelque chose
    }

}
