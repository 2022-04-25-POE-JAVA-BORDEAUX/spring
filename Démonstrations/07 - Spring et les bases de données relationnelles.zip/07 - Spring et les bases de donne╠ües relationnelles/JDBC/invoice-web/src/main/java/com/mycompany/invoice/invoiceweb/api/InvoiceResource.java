package com.mycompany.invoice.invoiceweb.api;

import com.mycompany.invoice.core.entity.Invoice;
import com.mycompany.invoice.core.service.InvoiceServiceInterface;
import com.mycompany.invoice.invoiceweb.form.InvoiceForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/invoice")
public class InvoiceResource {

    @Autowired
    private InvoiceServiceInterface service;

    @PostMapping
    public Invoice create(@RequestBody Invoice invoice) {

        return service.createInvoice(invoice);
    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }

    @GetMapping
    public List<Invoice> list(Model model) {
        return service.getInvoiceList();
    }

    @GetMapping("/{id}")
    public Invoice displayInvoice(@PathVariable("id") String number, Model model) {
        return service.getInvoiceByNumber(number);
    }

}
