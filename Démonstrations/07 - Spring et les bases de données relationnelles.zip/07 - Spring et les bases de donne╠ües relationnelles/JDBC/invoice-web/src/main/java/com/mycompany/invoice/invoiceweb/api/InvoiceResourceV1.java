package com.mycompany.invoice.invoiceweb.api;

import com.mycompany.invoice.core.entity.Invoice;
import com.mycompany.invoice.core.service.InvoiceServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// @Component
// @Controller
// @RequestMapping("/invoice")
public class InvoiceResourceV1 {

    @Autowired
    private InvoiceServiceInterface service;


    // Il va falloir transformer le texte qui arrive dans la requête pour en faire un objet de type invoice
    // j'utilise l'annotation @RequestBody
    @PostMapping
    public @ResponseBody Invoice create(@RequestBody Invoice invoice) {

        // je vais retourner l'identifiant ou l'objet au complet créé
        // je vais modifier le service pour qu'il me renvoit l'invoice créé
        
        return service.createInvoice(invoice);
    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }

    // pour respecter l'architecture elle sera accessible via l'url /invoice tout court
    @GetMapping
    public @ResponseBody List<Invoice> list(Model model) {
        return service.getInvoiceList();
    }

    @GetMapping("/{id}")
    public @ResponseBody Invoice displayInvoice(@PathVariable("id") String number, Model model) {
        return service.getInvoiceByNumber(number);
    }

    /*
    @GetMapping("/create-form")
    public String displayInvoiceCreateForm(@ModelAttribute InvoiceForm invoiceForm) {
        return "invoice-create-form";
    }*/
}
