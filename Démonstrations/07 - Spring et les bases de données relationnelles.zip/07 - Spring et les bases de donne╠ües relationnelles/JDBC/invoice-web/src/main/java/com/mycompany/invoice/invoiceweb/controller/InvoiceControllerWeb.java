package com.mycompany.invoice.invoiceweb.controller;

import com.mycompany.invoice.core.controller.InvoiceControllerInterface;
import com.mycompany.invoice.core.entity.Invoice;
import com.mycompany.invoice.core.service.InvoiceServiceInterface;
import com.mycompany.invoice.invoiceweb.form.InvoiceForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;

// @Component
@Controller
@RequestMapping("/invoice")
public class InvoiceControllerWeb {

    @Autowired
    private InvoiceServiceInterface service;


    // j'ai modifié ici l'url pour exploiter mes donnés en synchrones et asynchrones
    @PostMapping("/create")
    public String createInvoice(@Valid @ModelAttribute InvoiceForm invoiceForm, BindingResult results) {

        if(results.hasErrors()) {
            return "invoice-create-form";
        }

        // Je peux faire ça à la main car j'ai pas beaucoup de champs
        Invoice invoice = new Invoice();
        invoice.setCustomerInvoice(invoiceForm.getCustomerInvoice());
        invoice.setNumber(invoiceForm.getNumber());

        service.createInvoice(invoice);

        return "invoice-created";
    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }


    @GetMapping("/home")
    public String displayHome(Model model) {
        model.addAttribute("invoices", service.getInvoiceList());
        return "invoice-home";
    }

    /*
    @GetMapping("/{id}")
    public String displayInvoice(@PathVariable("id") String number, Model model) {
        model.addAttribute("invoice", service.getInvoiceByNumber(number));
        return "invoice-details";
    }*/


    @GetMapping("/create-form")
    public String displayInvoiceCreateForm(@ModelAttribute InvoiceForm invoiceForm) {
        return "invoice-create-form";
    }
}
