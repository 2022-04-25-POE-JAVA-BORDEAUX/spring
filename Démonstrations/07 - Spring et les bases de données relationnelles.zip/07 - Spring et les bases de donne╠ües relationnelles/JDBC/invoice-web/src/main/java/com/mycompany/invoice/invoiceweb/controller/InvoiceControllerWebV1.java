package com.mycompany.invoice.invoiceweb.controller;

import com.mycompany.invoice.core.controller.InvoiceControllerInterface;
import com.mycompany.invoice.core.controller.InvoiceControllerInterfacev1;
import com.mycompany.invoice.core.entity.Invoice;
import com.mycompany.invoice.core.service.InvoiceServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

// @Component

public class InvoiceControllerWebV1 implements InvoiceControllerInterfacev1 {

    @Autowired
    private InvoiceServiceInterface service;

    public void createInvoice() {

        String customerName = "Nike"; // je simule que j'ai reçu cette donnée depuis mon formulaire
        Invoice newInvoice = new Invoice();
        newInvoice.setCustomerInvoice(customerName);

        service.createInvoice(newInvoice);
    }

    public InvoiceServiceInterface getService() {
        return service;
    }

    public void setService(InvoiceServiceInterface service) {
        this.service = service;
    }

    // part 1
/*    @RequestMapping("/invoice-home")
    public String displayHome() {
        System.out.println("Home displayed !");
        //return "";
        return "index";
    }*/

    // part 2
/*    @RequestMapping("/invoice-home")
    public @ModelAttribute("invoices")
    String displayHome(HttpServletRequest request) {
        List<Invoice> listInvoices = service.getInvoiceList(); // je récupère la liste de factures
        request.setAttribute("invoices", listInvoices);
        return "index";
    }*/

    // part 3
    @RequestMapping("/invoice-home")
    public @ModelAttribute("invoices")
    List<Invoice> displayHome() {
        List<Invoice> listInvoices = service.getInvoiceList(); // je récupère la liste de factures
        return listInvoices;
    }
}
