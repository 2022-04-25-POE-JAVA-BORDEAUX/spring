package com.mycompany.invoice;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan( basePackages = { "com.mycompany.invoice.controller.web", "com.mycompany.invoice.service.prefix", "com.mycompany.invoice.repository.memory" })
//@PropertySource("classpath:application.properties")
@ImportResource("classpath:applicationContext.xml") // si je souhaite garder en complément le fichier xml
public class AppConfig {

}
