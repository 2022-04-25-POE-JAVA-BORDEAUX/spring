package com.mycompany.invoice.repository;

import com.mycompany.invoice.entity.Invoice;

public interface InvoiceRepositoryInterface {

    public void createInvoice(Invoice invoice);

}
