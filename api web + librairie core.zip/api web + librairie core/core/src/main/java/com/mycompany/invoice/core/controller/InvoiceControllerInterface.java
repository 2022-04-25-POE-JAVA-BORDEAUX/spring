package com.mycompany.invoice.core.controller;

import com.mycompany.invoice.core.service.InvoiceServiceInterface;

public interface InvoiceControllerInterface {

    public void createInvoice();

    public void setService(InvoiceServiceInterface service);
}
