package com.mycompany.invoice.core.repository;

import com.mycompany.invoice.core.entity.Invoice;

import java.util.List;

public interface InvoiceRepositoryInterface {

    public void createInvoice(Invoice invoice);
    public List<Invoice> list();

}
